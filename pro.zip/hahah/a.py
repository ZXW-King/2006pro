print('nihao')
